package com.example.calculator.theme

import androidx.compose.material3.Typography

val CalculatorTypography = Typography(
    // Defina aqui a tipografia que será usada
)